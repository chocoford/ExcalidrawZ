import{al as o,am as n}from"./index-qST5Veh3.js";const l=(a,r)=>o.lang.round(n.parse(a)[r]);export{l as c};
//# sourceMappingURL=channel-B1Ylunbs.js.map
