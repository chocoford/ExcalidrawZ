const t=e=>`
### Scene content

\`\`\`
Paste scene content here
\`\`\`

### Sentry Error ID

${e}
`;export{t as default};
//# sourceMappingURL=bug-issue-template-BID_ABWq.js.map
