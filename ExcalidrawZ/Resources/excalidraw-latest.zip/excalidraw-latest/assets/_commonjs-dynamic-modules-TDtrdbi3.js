function r(o){throw new Error('Could not dynamically require "'+o+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}export{r as c};
//# sourceMappingURL=_commonjs-dynamic-modules-TDtrdbi3.js.map
