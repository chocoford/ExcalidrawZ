import{a as r}from"./graph-47jN0RAg.js";var a=4;function n(o){return r(o,a)}export{n as c};
//# sourceMappingURL=clone-CzYN5oRg.js.map
